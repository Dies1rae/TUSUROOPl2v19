#include <iostream>
#include <string>
#include "office.h"
#include "printer.h"
using namespace std;
#pragma once


Office First(6);
Printer *prn = new Printer[6];

