#include <cmath>
#include <iomanip>
#include <tchar.h>
#include <conio.h>
#include <iostream>
#include <Windows.h>
#include <fstream>
#include <string>
#include <iostream>
#include <stdio.h>
#include "printer.h"
#include "office.h"
using namespace std;
#pragma once

Printer print(0, "HP LJ 335", 100);

